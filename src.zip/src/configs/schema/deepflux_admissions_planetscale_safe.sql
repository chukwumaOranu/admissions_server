-- MySQL dump 10.13  Distrib 8.0.44, for macos15 (arm64)
--
-- Host: 127.0.0.1    Database: deepflux_admissions
-- ------------------------------------------------------
-- Server version	9.5.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- GTID state at the beginning of the backup 
--

--
-- Table structure for table `admission_results`
--

DROP TABLE IF EXISTS `admission_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicant_id` int NOT NULL,
  `total_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `average_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `benchmark_score` decimal(8,2) NOT NULL DEFAULT '0.00',
  `is_successful` tinyint(1) NOT NULL DEFAULT '0',
  `admission_status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `decision_notes` text COLLATE utf8mb4_unicode_ci,
  `decided_by` int DEFAULT NULL,
  `decided_at` timestamp NULL DEFAULT NULL,
  `letter_ref` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `letter_payload` json DEFAULT NULL,
  `letter_generated_at` timestamp NULL DEFAULT NULL,
  `letter_sent` tinyint(1) NOT NULL DEFAULT '0',
  `letter_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `applicant_id` (`applicant_id`),
  KEY `decided_by` (`decided_by`),
  KEY `idx_results_successful` (`is_successful`),
  KEY `idx_results_status` (`admission_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_results`
--

--
-- Table structure for table `admission_settings`
--

DROP TABLE IF EXISTS `admission_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `benchmark_score` decimal(8,2) NOT NULL DEFAULT '180.00',
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_settings`
--

INSERT INTO `admission_settings` VALUES (1,180.00,NULL,'2026-03-04 13:08:55','2026-03-04 13:08:55');

--
-- Table structure for table `admission_subjects`
--

DROP TABLE IF EXISTS `admission_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admission_subjects` (
  `id` int NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_score` decimal(6,2) NOT NULL DEFAULT '100.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `subject_name` (`subject_name`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admission_subjects`
--

--
-- Table structure for table `applicant_subject_scores`
--

DROP TABLE IF EXISTS `applicant_subject_scores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant_subject_scores` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicant_id` int NOT NULL,
  `subject_id` int NOT NULL,
  `score` decimal(6,2) NOT NULL DEFAULT '0.00',
  `entered_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_applicant_subject` (`applicant_id`,`subject_id`),
  KEY `entered_by` (`entered_by`),
  KEY `idx_scores_applicant` (`applicant_id`),
  KEY `idx_scores_subject` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant_subject_scores`
--

--
-- Table structure for table `applicants`
--

DROP TABLE IF EXISTS `applicants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicants` (
  `id` int NOT NULL AUTO_INCREMENT,
  `application_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` int NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nationality` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `emergency_contact_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `emergency_contact_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `passport_photo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `exam_date_id` int DEFAULT NULL,
  `status` enum('draft','submitted','approved') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `payment_status` enum('pending','paid','failed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `payment_reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `reviewed_by` int DEFAULT NULL,
  `review_notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `custom_data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `application_number` (`application_number`),
  KEY `schema_id` (`schema_id`),
  KEY `exam_date_id` (`exam_date_id`),
  KEY `reviewed_by` (`reviewed_by`),
  KEY `idx_applicants_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` VALUES (1,'APP20250001',1,'Michael','Brown','','michael.brown@parent.com','+2348066665555','2010-09-25','male',NULL,'2nd Avenue','Mrs. Jane Brown','+2348077776666',NULL,21,1,'submitted','paid','ADM17606847580855UPCXL',NULL,NULL,NULL,NULL,'{\"class_type\": \"JSS 2\", \"previous_school\": \"Nazareth Sschool\"}','2025-10-16 11:17:37','2025-11-02 10:10:48'),(2,'APP2025250002',1,'anthony','Oranu','','anthony1@gmail.com','+2348038389474','1982-06-30','male',NULL,'2nd Avenue 207 road block 2 flat 14','Oranu Williams','+2348035089474',NULL,24,1,'draft','paid','ADM17623771591944DXFES',NULL,NULL,NULL,NULL,'{\"class_type\": \"JSS 2\", \"previous_school\": \"Nazareth school Festac town\"}','2025-11-02 09:19:36','2025-11-05 21:13:26');

--
-- Table structure for table `application_schema_fields`
--

DROP TABLE IF EXISTS `application_schema_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_schema_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_id` int NOT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` enum('text','email','number','date','datetime','time','textarea','select','checkbox','radio','file','url','phone') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_options` json DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `validation_rules` json DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `schema_id` (`schema_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_schema_fields`
--

INSERT INTO `application_schema_fields` VALUES (1,1,'previous_school','Previous School','text',NULL,0,NULL,0,0,'2025-10-08 05:14:39','2025-10-15 12:41:47'),(2,1,'class_applying_for','Class Applying For','select','\"Primary 1,Primary 2,Primary 3,Primary 4,Primary 5,Primary 6\"',1,NULL,1,0,'2025-10-08 05:15:35','2025-10-16 09:22:44'),(3,1,'date_of_birth','Date of Birth','date',NULL,1,NULL,2,0,'2025-10-08 05:16:31','2025-10-15 12:42:05'),(4,1,'birth_certificate','Birth Certificate','file',NULL,1,NULL,5,1,'2025-10-08 05:16:31','2025-10-16 10:30:58'),(5,1,'class_type','Class Entry Applied for','select','\"JSS 1,JSS 2\"',1,NULL,4,1,'2025-10-16 10:29:33','2025-10-16 10:31:01'),(6,1,'previous_school','Name of Previous School','text',NULL,1,NULL,3,1,'2025-10-16 10:30:46','2025-10-16 10:32:50'),(7,1,'lastTerm_result','Copy of Last term acadeemic result','file',NULL,0,NULL,6,1,'2025-10-16 10:32:04','2025-10-16 10:38:00'),(8,2,'Previous Class Level','Previous Class Level','text',NULL,1,NULL,1,1,'2026-03-05 10:47:37','2026-03-05 10:48:38'),(9,2,'Name of Previous School','Name of Previous School','text',NULL,1,NULL,0,1,'2026-03-05 10:48:32','2026-03-05 10:48:38');

--
-- Table structure for table `application_schemas`
--

DROP TABLE IF EXISTS `application_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application_schemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `application_fee` decimal(10,2) DEFAULT '0.00',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `schema_name` (`schema_name`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application_schemas`
--

INSERT INTO `application_schemas` VALUES (1,'Admission Academic Year 2026','St Thomas Primary School - Admission ','New intakes for the new academic session',1000.00,1,'2025-10-08 04:01:16','2025-10-16 09:07:06',14),(2,'JSS 2 Admission Academic Year 2026','Deepflux Academic','This is an appplication for new intake into JSS 2',1000.00,1,'2026-03-05 09:31:46','2026-03-05 09:31:46',14);

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `manager_id` int DEFAULT NULL,
  `budget` decimal(12,2) DEFAULT '0.00',
  `location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`),
  KEY `created_by` (`created_by`),
  KEY `idx_departments_name` (`name`),
  KEY `idx_departments_code` (`code`),
  KEY `idx_departments_manager` (`manager_id`),
  KEY `idx_departments_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` VALUES (1,'Administration','ADMIN','Administrative staff and management',NULL,500000.00,'Main Building - Floor 1',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-07 11:47:46',NULL),(2,'Academic Affairs','ACAD','Teaching staff and academic affairs',NULL,1200000.00,'Academic Building - Floor 2',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(3,'Finance','FIN','Financial management and accounting',NULL,300000.00,'Finance Office - Floor 1',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(4,'Information Technology','IT','IT support and system administration',NULL,200000.00,'IT Department - Floor 3',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(5,'Human Resources','HR','Human resources management',NULL,150000.00,'HR Office - Floor 1',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(6,'Student Affairs','STU','Student services and support',NULL,400000.00,'Student Center - Floor 2',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(7,'Maintenance','MAINT','Facilities and maintenance',NULL,100000.00,'Maintenance Building',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL),(8,'Security','SEC','Campus security and safety',NULL,180000.00,'Security Office - Ground Floor',NULL,NULL,1,'2025-10-05 06:00:46','2025-10-05 06:00:46',NULL);

--
-- Table structure for table `document_templates`
--

DROP TABLE IF EXISTS `document_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `template_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `template_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `html_body` longtext COLLATE utf8mb4_unicode_ci,
  `placeholders_json` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `version` int NOT NULL DEFAULT '1',
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_template_version` (`template_key`,`version`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`),
  KEY `idx_template_key_active` (`template_key`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_templates`
--

INSERT INTO `document_templates` VALUES (1,'admission_letter','Default Admission Letter','Provisional Admission Letter','PROVISIONAL ADMISSION LETTER\n\nReference: {{reference}}\nDate Issued: {{issued_date}}\n\nDear {{student_name}},\n\nCongratulations. You have been offered provisional admission into {{school_name}}.\n\nApplication Number: {{application_number}}\nCandidate Email: {{student_email}}\n\nNext Steps:\n1. Login to the portal with your credentials.\n2. Complete profile and required documentation.\n3. Pay applicable admission and screening fees.\n4. Print your exam/admission card where applicable.\n\nThis offer remains provisional until all requirements are met and verified.\n\nAdmissions Office\n{{school_name}}','<h1>PROVISIONAL ADMISSION LETTER</h1><p>Reference: {{reference}}</p><p>Date Issued: {{issued_date}}</p><p>Dear {{student_name}},</p><p>Congratulations. You have been offered provisional admission into {{school_name}}.</p><p><strong>Application Number:</strong> {{application_number}}</p><p><strong>Candidate Email:</strong> {{student_email}}</p><p><strong>Next Steps</strong></p><ol><li>Login to the portal with your credentials.</li><li>Complete profile and required documentation.</li><li>Pay applicable admission and screening fees.</li><li>Print your exam/admission card where applicable.</li></ol><p>This offer remains provisional until all requirements are met and verified.</p><p>Admissions Office<br/>{{school_name}}</p>','[\"reference\", \"issued_date\", \"student_name\", \"application_number\", \"student_email\", \"school_name\"]',1,1,NULL,NULL,'2026-03-05 16:01:41','2026-03-05 16:01:41');

--
-- Table structure for table `email_settings`
--

DROP TABLE IF EXISTS `email_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int DEFAULT '587',
  `smtp_secure` tinyint(1) DEFAULT '0',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verification_enabled` tinyint(1) DEFAULT '1',
  `welcome_email_enabled` tinyint(1) DEFAULT '1',
  `notification_email_enabled` tinyint(1) DEFAULT '1',
  `email_templates` json DEFAULT NULL,
  `custom_settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_settings`
--

INSERT INTO `email_settings` VALUES (1,'deepflux.com.ng',465,0,'info@deepflux.com.ng','infamous1980#','Deepflux schools','info@deepflux.com.ng',NULL,NULL,1,1,1,'{}','{}','2025-10-25 10:56:09','2025-10-25 10:56:09',14,14);

--
-- Table structure for table `employee_schema_fields`
--

DROP TABLE IF EXISTS `employee_schema_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_schema_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_id` int NOT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` enum('text','email','number','date','datetime','time','textarea','select','checkbox','radio','file','url','phone') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_options` json DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `validation_rules` json DEFAULT NULL,
  `display_order` int DEFAULT '0',
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `schema_id` (`schema_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_schema_fields`
--

--
-- Table structure for table `employee_schemas`
--

DROP TABLE IF EXISTS `employee_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_schemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `schema_name` (`schema_name`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_schemas`
--

INSERT INTO `employee_schemas` VALUES (1,'standard_employee','Standard Employee','Standard employee schema',1,'2025-10-07 16:54:19','2025-10-07 16:54:19',14);

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employees` (
  `id` int NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` int NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `department` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employment_date` date DEFAULT NULL,
  `salary` decimal(10,2) DEFAULT NULL,
  `status` enum('active','inactive','terminated','on_leave') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `profile_image` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_data` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `welcome_email_sent` tinyint(1) DEFAULT '0',
  `welcome_email_sent_at` timestamp NULL DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `schema_id` (`schema_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_employees_department_id` (`department_id`),
  KEY `idx_employees_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` VALUES (2,'EMP100',1,'Jane','Smith','jane.smith@company.com','+1234567890',NULL,'HR Manager','2025-01-20',NULL,'active',NULL,NULL,'2025-10-07 17:00:38','2025-10-07 17:00:38',14,16,0,NULL,2),(3,'EMP200',1,'Bob','Johnson','bob.johnson@company.com','+1234567890',NULL,'Accountant','2025-02-01',NULL,'active',NULL,NULL,'2025-10-07 17:01:14','2025-10-23 18:12:30',14,17,0,NULL,3),(5,'EMP205',1,'Amaka','Oranu','oranu2@outlook.com','+447466588150',NULL,'Accountant','2025-10-10',NULL,'active',NULL,NULL,'2025-10-23 18:27:16','2025-10-23 18:27:16',14,23,1,'2025-10-23 17:27:17',1);

--
-- Table structure for table `entry_dates`
--

DROP TABLE IF EXISTS `entry_dates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entry_dates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `exam_title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `exam_date` date NOT NULL,
  `exam_time` time NOT NULL,
  `exam_duration` int DEFAULT '120',
  `exam_venue` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exam_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `max_capacity` int DEFAULT '100',
  `current_registrations` int DEFAULT '0',
  `registration_deadline` date DEFAULT NULL,
  `instructions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `requirements` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry_dates`
--

INSERT INTO `entry_dates` VALUES (1,'Admission Batch 1','CBT Based Interview','2025-10-31','10:00:00',120,'School Auditorium','St thomas College ',100,0,'2025-10-22','Come with you writting materials','Pen and paper',1,'2025-10-16 16:37:13','2025-10-16 16:37:13',14),(2,'Entry Exam','Interview exam','2025-10-30','10:00:00',120,'school hall','st thomas college',100,0,'2025-10-22','its now for testing','come with pen and paper',0,'2025-10-17 18:26:01','2025-10-19 04:45:46',14),(3,'CBT Exam Maths','Writing mathematics exam','2026-04-09','10:00:00',120,'school hall','Deepflux school complex',5,0,'2026-03-26','Come with all your writing material','Attendance',1,'2026-03-05 08:59:11','2026-03-05 19:07:34',14);

--
-- Table structure for table `exam_cards`
--

DROP TABLE IF EXISTS `exam_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exam_cards` (
  `id` int NOT NULL AUTO_INCREMENT,
  `applicant_id` int NOT NULL,
  `entry_date_id` int NOT NULL,
  `card_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `qr_code_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `qr_code_image` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_image` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_pdf` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_printed` tinyint(1) DEFAULT '0',
  `printed_at` timestamp NULL DEFAULT NULL,
  `printed_by` int DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card_number` (`card_number`),
  KEY `applicant_id` (`applicant_id`),
  KEY `entry_date_id` (`entry_date_id`),
  KEY `printed_by` (`printed_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exam_cards`
--

INSERT INTO `exam_cards` VALUES (1,1,1,'CARD20250001','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAklEQVR4AewaftIAAAvaSURBVO3BQY7dWJIAQXci739ln9oQiMU8ivkrJVUDYWb/YK31/7pYax1drLWOLtZaRxdrraOLtdbRxVrr6GKtdfTFL6j8CRWTylQxqUwVN5Wp4qeoTBWTyknFpPJTKt5SeatiUnlS8ZbKVDGp/AkVJxdrraOLtdbRxVrr6ItvqvgpKicVk8pU8ZbKk4qbylQxVbxVMalMFW+pTBUnKt9RcaIyVTxR+R0qforKWxdrraOLtdbRxVrr6It/SeWtik9VTCpTxa3ip6g8qfivq/gOlVvFpDJVTBUnKj9F5a2KT12stY4u1lpHX/xHqTypeEtlqphUbhVPVCaVqeItlanipjJVPFH5lMqnVE4qnlT8112stY4u1lpHF2utoy/+R1T8LhU3laniO1RuFd+hcqLyKZWp4knFpypOKv7XXKy1ji7WWkcXa62jL/6lij9BZaqYVN5SmSpuFZPKVPFE5abypOItlaliUrlVPFF5onJS8ZbKVPFTKv6Ei7XW0cVa6+hirXX0xTep/A0Vk8pUcVOZKiaVE5WpYlKZKk4qJpUnKreKn6IyVUwqU8VN5YnKVPGWylRxovI3XKy1ji7WWkdf/ELFf4HK76Jyq3hS8aTipvIdFW+pfErlicqt4jtU3qp4UvG3Xay1ji7WWkcXa62jL35BZap4S2WqmFQ+VXFS8VNUnlRMKreKSWVS+VTFpyreUpkqnlScqEwVk8pPqThRmSpOLtZaRxdrraOLtdbRF9+k8lbFpDJVnKhMFW+pTBVvqXyHylsVk8pJxaTyROWk4lMVTypOVP6Nip+gMlW8dbHWOrpYax1drLWOvviFiicqt4pJ5YnKrWKq+A6VE5W3KiaVqWJSmSo+VfGWyknFd6icVEwqU8VbFd+h8lbFpPITLtZaRxdrraOLtdaR/YMHKk8qTlSeVPwOKlPFpDJV3FSmik+pfKpiUnlScVOZKiaVT1VMKlPFTeVJxROVW8Wk8qmKty7WWkcXa62jL36h4lMVT1RuFZPKVPFE5UTlicqt4onKWxWTylTxVsWk8pbKVDGpnFR8quKJylTxUypOVKaKk4u11tHFWuvoYq11ZP/gG1Smip+gMlV8SuVTFU9UpooTle+ouKk8qXhL5adUPFF5q2JSOan4Gy7WWkcXa62ji7XW0Rf/ksqtYlKZKiaVW8WfUnGi8qTiicpJxaQyqdwqvkPlVjFVfEplUpkqpoqbylTxU1SmiknlpOKti7XW0cVa6+hirXX0xS+o/BSVqeJEZap4onKrmFSeqLyl8lbFd1S8pfKWylTxJ1RMKlPFVPEplZOKSWWqOLlYax1drLWOvvimircqJpVJ5VbxHSqfUpkqTlS+o+KtiknlVvEplaliUpkqJpVbxROVqeKm8h0qJxVPKt6qeOtirXV0sdY6ulhrHX3xCxVvqTyp+JTKpyqeqNwqnlRMKicqU8VbKk8qJpUTlScqU8VbFZPKrWJS+ZTKVPGWypOKk4u11tHFWuvoYq119MUvqDypOKmYVE4qpopJZaqYVG4q31FxU5kqvkPlRGWqOKmYVJ5U3FSmiu9QuVU8UXmrYlKZKiaVW8UTlanipOKti7XW0cVa6+hirXVk/+CBylTxlspUcaIyVXxK5UnFpPKpiknlb6g4UZkqnqi8VTGp3Cq+Q+WkYlKZKiaVW8WnLtZaRxdrraOLtdbRF79QMamcVEwVk8pJxROVqeKk4jsqTlSmiknlpGJS+VTFT1GZKk4qPqUyVUwqU8WfoDJVnFystY4u1lpHX/xLFZ+quKk8qZhUpoqbypOKSeWk4knFpHJSMalMFW+pfKpiUpkqTlSeVNxUJpWpYlKZKm4q31FxUvHWxVrr6GKtdXSx1jr64hdUpooTle9QeUvlUxW/i8pUcVP5DpVPVdxUvqNiUrlVPKmYVG4VT1SeqHxK5VbxqYu11tHFWuvoYq119MU3qUwVb1W8pfKk4lMqP6XiUxVvqUwVf4LKE5W3VJ5UvKUyqfwOF2uto4u11tHFWuvoi1+o+F1UbhVPKv6Eiu9QOamYVJ6o3Co+VTGpTCpPKm4qU8WkcqIyVUwqT1RuFU8qJpUTlani5GKtdXSx1jr64hdUnlR8quJTKlPFrWJSmSomlROVqWKqmFQ+VfEplVvFd1ScVEwqTypuKv9GxacqbiqfulhrHV2stY4u1lpH9g8eqLxVMan8F1RMKj+lYlL5Gyo+pXJS8SmVqWJS+SkVv8PFWuvoYq11dLHWOrJ/8EBlqphUTiomlaniUypTxU3lScWkcqt4ojJVvKUyVUwqt4pPqUwVk8rvUnFT+Y6KSeVW8UTlrYq3LtZaRxdrraOLtdbRF9+k8pbKVDGp3ComlaliqphU3lKZKm4qU8V3qJxU/BSVqeJEZaqYVE4qnqi8VfFE5S2VqWJSuVVMKlPFycVa6+hirXX0xR+kMlX8DRWTyonKVDGpnFRMKk8q/gsqbipTxROVt1Smik+pTBU3lanirYu11tHFWuvoYq119MUvVDxROal4onKrmCqeqJxUTCpPKn5KxadUTiqeqHyqYlJ5q2JSuVVMKt+hcquYKiaVk4pPXay1ji7WWkcXa62jL34jlScVn6qYVE4qJpWp4qYyVTypOFF5UjGp3ComlaliUjmp+I6Km8oTlanirYpJZar4lMqtYlKZKk4u1lpHF2uto4u11tEXv6DyVsUTlUnlUxVvqUwVJxWTyqcqPqXyHRUnKj9F5VMVk8pUcaLypOJE5VMXa62ji7XW0cVa6+iLb6qYVG4qU8WTipvKVDGpfKpiUjmpmCqeqLylMlV8SmWqeKtiUjmpmFSeqLxVMan811ystY4u1lpHX/xCxZOKm8qkMlVMKreKSWWqeEtlqnhScVOZKiaVt1Q+VfFEZVI5qZhUfkrFicoTlaniROU7VG4Vk8pbF2uto4u11tHFWuvoi39J5VYxqTypuKn8Lio/peKJyknFpDJVvFVxojKpPKl4q+KJyknFE5WTip9S8dbFWuvoYq11dLHWOvriF1SeVNxUpopJ5a2KJypTxYnKVDGpvKXypOKm8imVqeKnVPwUlaniLZWp4kRlqphU3lKZKk4u1lpHF2uto4u11pH9g/8gle+oeEvlpOI7VKaKP0HlUxWTylRxovKk4qYyVXyHylsVJypPKk4u1lpHF2utoy++SWWqeEvlrYpJZap4S2WqmFRuKlPFT1GZKiaVW8Wk8rtUTCq3iicVb6k8qZgq3lKZKk4q3rpYax1drLWOLtZaR/YPvkHlrYq3VL6j4kRlqnhL5TsqTlSmirdUpopJ5aTiicpUMal8quJTKr9Dxacu1lpHF2uto4u11tEXv6DyVsV3qNwqfkrFpPK7qEwVt4pJ5VMqU8WkcqIyVUwqU8WJylsqU8Wk8lMqJpWfcLHWOrpYax1drLWOvviFit+l4kTlUxVPKk5UnlRMKpPKreJJxVsqTypOKiaVJyonFZPKWypPKt5SeUvlScXJxVrr6GKtdXSx1jr64hdU/oSKJxWTylRxU/ldVKaKSeWm8h0qt4onKlPFTWWqmCqeqLxVMamcVEwqT1RuFd9R8RMu1lpHF2utoy++qeKnqJxUTCpPVG4VT1TeqphUfpeKv0HlLZUnFScq31Hxt12stY4u1lpHF2utoy/+JZW3Kt5SmSqeqPwJFZPKScWkMqn8CSpTxVsVk8pbKlPFpDKp/AkqU8XJxVrr6GKtdXSx1jr64j+q4lMqU8VUcaLyRGWqOFGZKiaVn6Jyq5hUJpWp4kTlUxXfUfE7qEwVb12stY4u1lpHF2utoy/+R6i8VfGpiicVT1ROVKaKE5WpYlJ5q+I7VD6lcquYVKaKJyonFZPKVPETLtZaRxdrraMv/qWKP6HiicpbKn9DxaRyUvFTVKaKn1JxovJE5a2KJxW/w8Va6+hirXV0sdY6+uKbVP4ElaliUnlLZaqYVG4Vk8pU8ZbKpPKk4kTlUxWTylQxVbyl8lbFp1S+o+JEZao4uVhrHV2stY4u1lpH9g/WWv+vi7XW0cVa6+hirXV0sdY6ulhrHV2stY7+DwUEsvTqKWKaAAAAAElFTkSuQmCC','uploads/qr-codes/exam-card-1-1760861157829-qr.png',NULL,'uploads/exam-cards/exam-card-1-1760861157829.pdf',0,NULL,NULL,'2025-10-19 08:05:57'),(2,2,1,'CARD2025250002','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAklEQVR4AewaftIAAAvVSURBVO3BQY7dWJIAQXci739ln9oQiMU8ivmVUlUDYWb/YK31/7pYax1drLWOLtZaRxdrraOLtdbRxVrr6GKtdfTFL6j8DRWTyp9SMancKr5D5a2KSeWnVLyl8qTiROVJxVsqU8Wk8jdUnFystY4u1lpHF2utoy++qeKnqJxUPFE5qfiUylQxqUwVb6lMFW+pTBUnKt9RMamcVEwqk8qfUPFTVN66WGsdXay1ji7WWkdf/CaVtyr+lIoTlU+pTBWTylTxX1PxqYpJZap4S+WnqLxV8amLtdbRxVrr6Iv/KJWp4onKScVPUfkpKlPFTWWqeKLyKZVPqZxUPKn4r7tYax1drLWOLtZaR1/8j1CZKiaVW8WkMlVMKreKJxWTyqRyq/gOlROVT6lMFU8qPlVxUvG/5mKtdXSx1jq6WGsdffGbKv4LKm4qT1TeUpkqpopJ5abypOItlaliUrlVPFF5onJS8ZbKVPFTKv6Gi7XW0cVa6+hirXX0xTep/BsqJpWp4qRiUpkqbipTxaQyVZxUTCpPVG4VP0VlqphUpoqbyhOVqeItlaniROXfcLHWOrpYax198QsV/wUqT1RuFX9KxZOKm8p3VLyl8imVJyq3iu9QeaviScW/7WKtdXSx1jq6WGsdffELKlPFWypTxaTyqYqfonKrmFSeVEwqt4pJZVL5VMWnKt5SmSqeVJyoTBWTyk+pOFGZKk4u1lpHF2uto4u11pH9g29QOan4lMpU8SmVqWJS+RsqnqicVEwqU8WkclLxb1D5HRU/QWWqeOtirXV0sdY6ulhrHX3xCypvqUwVk8pbKlPFE5W3KiaVW8WkMlVMKlPFpyreUjmp+A6Vk4pJZar4VMWkMqm8VTGp/ISLtdbRxVrr6GKtdfTFD6qYVKaKT6k8qbipfEfFTeWJylRxovIdKreK76i4qUwVk8pbKlPFpDJVvKUyVUwqt4pJZVL5Ey7WWkcXa62jL76pYlJ5S+WkYlJ5UjGp3Cq+Q+WtiknlpGJSmSreqphU3lKZKiaVk4pPVTxR+VMqTlSmipOLtdbRxVrr6GKtdWT/4IHKVPGWypOKm8pU8R0qt4pPqTypeEvlOypuKk8q3lL5KRVPVN6qmFROKv4NF2uto4u11tHFWuvI/sE3qEwVb6mcVHyHylsVT1RuFZPKk4pJ5aRiUjmp+A6VW8VPUXlScaIyVTxROamYVKaKSeWk4q2LtdbRxVrr6GKtdfTFL6i8pfIdFScq31HxlspU8VbFpHJS8R0Vb6m8pTJVPFG5VTxRmSpuFZPKVDFVfErlpGJSmSpOLtZaRxdrraMvvqnipGJSeaJyq/hTVKaKP6XirYpJ5VbxKZWpYlKZKqaKE5Wp4kTlO1ROKp5UvFXx1sVa6+hirXV0sdY6sn/wQ1Smip+iMlW8pfKpiknlScVNZap4ovJWxaTyUypOVN6qmFSmiknlrYq3VJ5UnFystY4u1lpHF2utI/sHD1SmihOVqeKJyq1iUvkpFZPKScV3qHyqYlK5VUwqU8WJylTxp6i8VTGpTBWTyq3iicpUcVOZKt66WGsdXay1ji7WWkf2D75BZao4UZkqTlSmiicqJxWTylsVk8qTiknl31BxojJVPFF5q2JSuVV8h8pJxaQyVUwqt4pPXay1ji7WWkcXa62jL36Tyq1iqphUTiq+o+KtiknlrYonKicVk8qnKn6KylQxVdxUpoq3VKaKSWWq+BtUpoqTi7XW0cVa68j+wW9QOamYVKaKT6lMFScqn6r4DpVbxROVqeItlU9VTCpTxYnKk4qbypOKSWWquKk8qfgTLtZaRxdrraOLtdaR/YPfoPJfU/EdKicVT1SmipvK31JxU3lS8UTlVjGpTBWTyq3iicqfUvETLtZaRxdrraOLtdbRF7+p4qbypOItlScVJypTxaTyUyo+VfGWylTxN6g8UXlL5UnFWypPVG4Vn7pYax1drLWOLtZaR1/8gspUMal8SuVW8aTib6j4DpWTiknlicqt4lMVk8qk8qTipjJVTConKlPFpPJE5VbxpGJSOVGZKk4u1lpHF2utoy9+oWJSOamYVJ5UfEplqrhVTCpTxaRyojJVTBWTyqcqPqVyq/iOipOKSeVJxU3ld1R8quKm8qmLtdbRxVrr6GKtdWT/4IHKVPGWyk+pmFT+hopJZaqYVP4NFZ9SOan4lMrfUvEnXKy1ji7WWkcXa62jL36hYlJ5q2JSmSreUnlScVP5VMWk8h0VJypTxaRyq/iUylQxqbyl8h0Vn6qYVG4VT1TeqnjrYq11dLHWOrpYax198QsqTypuKpPKVDGpnFRMFZPKT6m4qUwV36FyUvFTVKaKE5WpYlI5qXii8lbFE5W3VKaKSeVWMalMFScXa62ji7XW0Re/UDGpvFXxpOJEZap4ovITKiaVqWJSOamYVJ5U/BdU3FSmiicqn6r4lMpUcVOZKt66WGsdXay1ji7WWkdffFPFpHKi8lbFd1T8FJVbxe+o+JTKScUTlU9VTCpvVUwqt4onKlPFpHKrmComlZOKT12stY4u1lpHF2utoy/+oIpJZap4S2WqmFTeqjhReaIyVZyoPKmYVG4Vk8pUMamcVPwpKlPFicpUMalMFZ9SuVVMKlPFycVa6+hirXV0sdY6+uIXVN6qeFIxqXxKZaq4qUwVk8pUcVP5DpWTik+pfEfFicp3VNxUvkPlpGJSmSpOVJ5UnKh86mKtdXSx1jq6WGsdffFNFZPKTeU7Km4qU8UTlUnlVvFTKp6ovKUyVXxKZap4q2JSmVR+QsWkMlVMKv81F2uto4u11tEXv1DxpOKmMlVMKpPKrWJSeVIxqZyo/BtUPlXxRGVSOamYVP4GlScqU8WJyneo3Comlbcu1lpHF2uto4u11tEXv0nlVjGpTBUnKk8qJpW/QeVJxaRyUjGpTBVvVZyoTCpPKj5VMamcVDxROan4KRVvXay1ji7WWkcXa62jL35TxadU3lJ5S+U7VG4Vk8oTlanipvIplanip1T8FJWp4i2VqeJEZaqYVN5SmSpOLtZaRxdrraOLtdaR/YMHKlPFpHJS8VNUnlS8pTJV3FSeVEwqU8XfoPKpikllqjhReVJxU5kqvkPlrYoTlScVJxdrraOLtdbRF79QMalMFW+pnFRMKk8qTlSeVLxV8VNUpopJ5VYxqfwpFZPKreJJxVsqTyqmirdUpoqTircu1lpHF2uto4u11pH9g29QeaviUypPKn6Kyq1iUnlScaIyVbylMlVMKicVT1SmiknlUxWfUvkTKj51sdY6ulhrHV2stY6++AWVtyq+Q+VW8aTiUypvqXyHylRxq5hUPqUyVUwqJypTxaQyVZyovKUyVUwqP6ViUvkJF2uto4u11tHFWuvoi1+o+FMq3lJ5q+JJxYnKk4pJZVK5VTypeEvlScVJxaTyROWkYlJ5S+VJxVsqb6k8qTi5WGsdXay1ji7WWkdf/ILK31DxpGJSmSpuKlPFpDJVnFRMKlPFpHJT+Q6VW8UTlanipjJVTBVPVN6qmFROKiaVJyq3iu+o+AkXa62ji7XW0RffVPFTVE4qJpWpYlK5VUwqT1TeqvhTKv4NKm+pPKk4UfmOin/bxVrr6GKtdXSx1jr64jepvFXxlspU8aTipvKkYlK5VTxReatiUplU/gaVqeKtiknlLZWpYlKZVP4Glani5GKtdXSx1jq6WGsdffEfVTGpTBWTyq1iUplUTlSmiqniLZWpYlL5KSq3ikllUpkqTlQ+VTGpTBV/g8pU8dbFWuvoYq11dLHWOvrif0TFk4qbypOKP0XlRGWqOFGZKiaVtyq+Q+VTKreKqWJSmSomlZOKSWWq+AkXa62ji7XW0Re/qeLfoHJSMan8FJVPVUwqJxU/RWWqmFSmipvKk4qfonJS8aTiT7hYax1drLWOLtZaR198k8rfoPJTKiaVqeKmMlU8qThRmVSeVJyofKpiUvlUxaRyUvGk4i2V76g4UZkqTi7WWkcXa62ji7XWkf2Dtdb/62KtdXSx1jq6WGsdXay1ji7WWkcXa62j/wNH06329PZpmwAAAABJRU5ErkJggg==','uploads/qr-codes/exam-card-2-1762377207121-qr.png',NULL,'uploads/exam-cards/exam-card-2-1762377207121.pdf',0,NULL,NULL,'2025-11-05 21:13:27');

--
-- Table structure for table `file_uploads`
--

DROP TABLE IF EXISTS `file_uploads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_uploads` (
  `id` int NOT NULL AUTO_INCREMENT,
  `original_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint NOT NULL,
  `file_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_category` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded_by` int NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `metadata` json DEFAULT NULL,
  `uploaded_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `file_name` (`file_name`),
  KEY `uploaded_by` (`uploaded_by`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file_uploads`
--

INSERT INTO `file_uploads` VALUES (9,'deepfluxLogo.png','logo-1760844594610-642762109.png','uploads/school/logo-1760844594610-642762109.png',283987,'image','image/png','school_logo',14,'School logo upload',NULL,'2025-10-19 03:29:54','2025-10-19 03:29:54'),(10,'web-app-manifest-512x512.png','favicon-1761093631027.png','uploads/school/favicon-1761093631027.png',126320,'image','image/png','favicon',14,'School favicon',NULL,'2025-10-22 00:40:31','2025-10-22 00:40:31'),(11,'web-app-manifest-512x512.png','favicon-1761093887061.png','uploads/school/favicon-1761093887061.png',126320,'image','image/png','favicon',14,'School favicon',NULL,'2025-10-22 00:44:47','2025-10-22 00:44:47'),(12,'web-app-manifest-512x512.png','favicon-1761095934646.png','uploads/school/favicon-1761095934646.png',126320,'image','image/png','favicon',14,'School favicon',NULL,'2025-10-22 01:18:54','2025-10-22 01:18:54');

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_transactions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `transaction_reference` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicant_id` int NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NGN',
  `payment_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'card',
  `payment_status` enum('pending','success','failed','cancelled') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `paystack_response` json DEFAULT NULL,
  `gateway_response` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `paid_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_reference` (`transaction_reference`),
  KEY `applicant_id` (`applicant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_transactions`
--

INSERT INTO `payment_transactions` VALUES (1,'ADM1760614529025S8ZSXD',1,1000.00,'NGN','card','pending',NULL,NULL,NULL,'2025-10-16 11:35:29','2025-10-16 11:35:29'),(2,'ADM1760614740098TLQUWF',1,1000.00,'NGN','card','pending',NULL,NULL,NULL,'2025-10-16 11:39:00','2025-10-16 11:39:00'),(3,'ADM1760615518634ABK45S',1,1000.00,'NGN','card','pending',NULL,NULL,NULL,'2025-10-16 11:51:58','2025-10-16 11:51:58'),(4,'ADM1760615919413Q2AI5V',1,1000.00,'NGN','card','pending',NULL,NULL,NULL,'2025-10-16 11:58:39','2025-10-16 11:58:39'),(5,'ADM1760616260449Z5H9SM',1,1000.00,'NGN','card','success','{\"id\": 5435180078, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 12, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 13, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760616263, \"time_spent\": 13}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T12:04:35.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T12:04:35.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"5\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T12:04:21.000Z\", \"reference\": \"ADM1760616260449Z5H9SM\", \"created_at\": \"2025-10-16T12:04:21.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_94sy3wkr4z\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T12:04:21.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 12:04:41','2025-10-16 12:04:20','2025-10-16 12:04:41'),(6,'ADM1760616667455O8WLJA',1,1000.00,'NGN','card','pending',NULL,NULL,NULL,'2025-10-16 12:11:07','2025-10-16 12:11:07'),(7,'ADM1760617049690OQY1BD',1,1000.00,'NGN','card','success','{\"id\": 5435230907, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 10, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 10, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760617052, \"time_spent\": 10}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T12:17:42.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T12:17:42.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"7\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T12:17:30.000Z\", \"reference\": \"ADM1760617049690OQY1BD\", \"created_at\": \"2025-10-16T12:17:30.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.93\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_b3r3s2qh28\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T12:17:30.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 12:17:49','2025-10-16 12:17:29','2025-10-16 12:17:49'),(8,'ADM1760617436421DNJ15P',1,1000.00,'NGN','card','success','{\"id\": 5435249706, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 4, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 5, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760617439, \"time_spent\": 5}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T12:24:03.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T12:24:03.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"8\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T12:23:56.000Z\", \"reference\": \"ADM1760617436421DNJ15P\", \"created_at\": \"2025-10-16T12:23:56.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_qctsvp55iz\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T12:23:56.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 12:24:06','2025-10-16 12:23:56','2025-10-16 12:24:06'),(9,'ADM17606180412041JCCWF',1,1000.00,'NGN','card','success','{\"id\": 5435277254, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 4, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 4, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760618045, \"time_spent\": 4}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T12:34:09.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T12:34:09.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"9\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T12:34:02.000Z\", \"reference\": \"ADM17606180412041JCCWF\", \"created_at\": \"2025-10-16T12:34:02.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_882lgujwmy\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T12:34:02.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 12:34:19','2025-10-16 12:34:01','2025-10-16 12:34:19'),(10,'ADM176061807848243SKYQ',1,1000.00,'NGN','card','success','{\"id\": 5435279288, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 20, \"type\": \"input\", \"message\": \"Filled this field: card number\"}, {\"time\": 20, \"type\": \"action\", \"message\": \"Switched transaction currency to USD\"}, {\"time\": 28, \"type\": \"input\", \"message\": \"Filled this field: card expiry\"}, {\"time\": 41, \"type\": \"input\", \"message\": \"Filled this field: card cvv\"}, {\"time\": 57, \"type\": \"action\", \"message\": \"Set payment method to: bank\"}, {\"time\": 58, \"type\": \"action\", \"message\": \"Set payment method to: card\"}, {\"time\": 62, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 63, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760618081, \"time_spent\": 63}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T12:35:43.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T12:35:43.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"10\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T12:34:39.000Z\", \"reference\": \"ADM176061807848243SKYQ\", \"created_at\": \"2025-10-16T12:34:39.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_1l046svs8u\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T12:34:39.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 12:35:46','2025-10-16 12:34:38','2025-10-16 12:35:46'),(11,'ADM17606198016045CL6P7',1,1000.00,'NGN','card','success','{\"id\": 5435363827, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 3, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 4, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760619804, \"time_spent\": 4}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T13:03:28.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T13:03:28.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"11\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T13:03:22.000Z\", \"reference\": \"ADM17606198016045CL6P7\", \"created_at\": \"2025-10-16T13:03:22.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_l4p6v4fvut\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T13:03:22.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 13:03:31','2025-10-16 13:03:21','2025-10-16 13:03:31'),(12,'ADM1760619842333J06BUH',1,1000.00,'NGN','card','success','{\"id\": 5435365645, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 4, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 5, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760619844, \"time_spent\": 5}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T13:04:08.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T13:04:08.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"12\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T13:04:02.000Z\", \"reference\": \"ADM1760619842333J06BUH\", \"created_at\": \"2025-10-16T13:04:02.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_ez3qg5wp1l\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T13:04:02.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 13:04:11','2025-10-16 13:04:02','2025-10-16 13:04:11'),(13,'ADM1760628356453HRI7CW',1,1000.00,'NGN','card','success','{\"id\": 5435683126, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 3, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 4, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760628360, \"time_spent\": 4}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T15:26:03.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T15:26:03.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"13\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T15:25:57.000Z\", \"reference\": \"ADM1760628356453HRI7CW\", \"created_at\": \"2025-10-16T15:25:57.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_cqnamnezl8\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T15:25:57.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 15:26:07','2025-10-16 15:25:56','2025-10-16 15:26:07'),(14,'ADM1760639692091XOYXSO',1,1000.00,'NGN','card','success','{\"id\": 5436088605, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 4, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 4, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760639696, \"time_spent\": 4}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-16T18:35:00.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-16T18:35:00.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"14\"}, \"order_id\": null, \"createdAt\": \"2025-10-16T18:34:53.000Z\", \"reference\": \"ADM1760639692091XOYXSO\", \"created_at\": \"2025-10-16T18:34:53.000Z\", \"fees_split\": null, \"ip_address\": \"92.40.189.178\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_19vvqpjl8p\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-16T18:34:53.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-16 18:35:05','2025-10-16 18:34:52','2025-10-16 18:35:05'),(15,'ADM17606847580855UPCXL',1,1000.00,'NGN','card','success','{\"id\": 5437387188, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 4, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 5, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1760684762, \"time_spent\": 5}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-10-17T07:06:06.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-10-17T07:06:06.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 312749971, \"email\": \"michael.brown@parent.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_hz7ji5urdsxqplx\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"1\", \"custom_fields\": [{\"value\": \"1\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"15\"}, \"order_id\": null, \"createdAt\": \"2025-10-17T07:05:58.000Z\", \"reference\": \"ADM17606847580855UPCXL\", \"created_at\": \"2025-10-17T07:05:58.000Z\", \"fees_split\": null, \"ip_address\": \"188.28.191.92\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_agm8lxie87\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-10-17T07:05:58.000Z\", \"pos_transaction_data\": null}',NULL,'2025-10-17 07:06:10','2025-10-17 07:05:58','2025-10-17 07:06:10'),(16,'ADM17623771591944DXFES',2,1000.00,'NGN','card','success','{\"id\": 5504581882, \"log\": {\"input\": [], \"errors\": 0, \"mobile\": false, \"history\": [{\"time\": 5, \"type\": \"action\", \"message\": \"Attempted to pay with card\"}, {\"time\": 5, \"type\": \"success\", \"message\": \"Successfully paid with card\"}], \"success\": true, \"attempts\": 1, \"start_time\": 1762377162, \"time_spent\": 5}, \"fees\": 1500, \"plan\": null, \"split\": {}, \"amount\": 100000, \"domain\": \"test\", \"paidAt\": \"2025-11-05T21:12:47.000Z\", \"source\": null, \"status\": \"success\", \"channel\": \"card\", \"connect\": null, \"message\": null, \"paid_at\": \"2025-11-05T21:12:47.000Z\", \"currency\": \"NGN\", \"customer\": {\"id\": 317177736, \"email\": \"anthony1@gmail.com\", \"phone\": null, \"metadata\": null, \"last_name\": null, \"first_name\": null, \"risk_action\": \"default\", \"customer_code\": \"CUS_d7cunrsef4sk5ly\", \"international_format_phone\": null}, \"metadata\": {\"referrer\": \"http://localhost:3000/\", \"applicant_id\": \"2\", \"custom_fields\": [{\"value\": \"2\", \"display_name\": \"Applicant ID\", \"variable_name\": \"applicant_id\"}], \"transaction_id\": \"16\"}, \"order_id\": null, \"createdAt\": \"2025-11-05T21:12:40.000Z\", \"reference\": \"ADM17623771591944DXFES\", \"created_at\": \"2025-11-05T21:12:40.000Z\", \"fees_split\": null, \"ip_address\": \"92.40.188.85\", \"subaccount\": {}, \"plan_object\": {}, \"authorization\": {\"bin\": \"408408\", \"bank\": \"TEST BANK\", \"brand\": \"visa\", \"last4\": \"4081\", \"channel\": \"card\", \"exp_year\": \"2030\", \"reusable\": true, \"card_type\": \"visa \", \"exp_month\": \"12\", \"signature\": \"SIG_WgnqLQZUPVUzUlSlTaai\", \"account_name\": null, \"country_code\": \"NG\", \"receiver_bank\": null, \"authorization_code\": \"AUTH_d4ksw8thxo\", \"receiver_bank_account_number\": null}, \"fees_breakdown\": null, \"receipt_number\": null, \"gateway_response\": \"Successful\", \"requested_amount\": 100000, \"transaction_date\": \"2025-11-05T21:12:40.000Z\", \"pos_transaction_data\": null}',NULL,'2025-11-05 21:12:52','2025-11-05 21:12:39','2025-11-05 21:12:52');

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_permissions_name` (`name`),
  KEY `idx_permissions_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=219 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` VALUES (24,'user.create','Create new users',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(25,'user.read','View user information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(26,'user.update','Update user information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(27,'user.delete','Delete users',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(28,'user.list','List all users',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(29,'user.activate','Activate/deactivate users',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(30,'user.reset_password','Reset user passwords',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(31,'role.create','Create new roles',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(32,'role.read','View role information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(33,'role.update','Update role information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(34,'role.delete','Delete roles',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(35,'role.list','List all roles',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(36,'role.assign','Assign roles to users',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(37,'permission.create','Create new permissions',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(38,'permission.read','View permission information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(39,'permission.update','Update permission information',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(40,'permission.delete','Delete permissions',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(41,'permission.list','List all permissions',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(42,'permission.assign','Assign permissions to roles',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(43,'employee.create','Create new employees',1,'2025-10-05 06:00:25','2025-10-05 06:00:25'),(44,'employee.read','View employee information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(45,'employee.update','Update employee information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(46,'employee.delete','Delete employees',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(47,'employee.list','List all employees',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(48,'employee.upload_profile','Upload employee profile pictures',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(49,'employee.export','Export employee data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(50,'employee.import','Import employee data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(51,'employee_schema.create','Create employee schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(52,'employee_schema.read','View employee schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(53,'employee_schema.update','Update employee schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(54,'employee_schema.delete','Delete employee schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(55,'employee_schema.list','List all employee schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(56,'employee_field.create','Create employee fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(57,'employee_field.read','View employee fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(58,'employee_field.update','Update employee fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(59,'employee_field.delete','Delete employee fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(60,'employee_field.list','List all employee fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(61,'department.create','Create new departments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(62,'department.read','View department information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(63,'department.update','Update department information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(64,'department.delete','Delete departments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(65,'department.list','List all departments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(66,'department.assign_manager','Assign department managers',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(67,'department.view_employees','View department employees',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(68,'application.create','Create new applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(69,'application.read','View application information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(70,'application.update','Update application information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(71,'application.delete','Delete applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(72,'application.list','List all applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(73,'application.approve','Approve applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(74,'application.reject','Reject applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(75,'application.review','Review applications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(76,'application.upload_passport','Upload applicant passport photos',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(77,'application.export','Export application data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(78,'application.import','Import application data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(79,'application_schema.create','Create application schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(80,'application_schema.read','View application schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(81,'application_schema.update','Update application schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(82,'application_schema.delete','Delete application schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(83,'application_schema.list','List all application schemas',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(84,'application_field.create','Create application fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(85,'application_field.read','View application fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(86,'application_field.update','Update application fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(87,'application_field.delete','Delete application fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(88,'application_field.list','List all application fields',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(89,'payment.create','Create new payments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(90,'payment.read','View payment information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(91,'payment.update','Update payment information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(92,'payment.delete','Delete payments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(93,'payment.list','List all payments',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(94,'payment.initialize','Initialize payment transactions',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(95,'payment.verify','Verify payment transactions',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(96,'payment.refund','Process payment refunds',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(97,'payment.export','Export payment data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(98,'payment.reports','Generate payment reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(99,'exam.create','Create exam entries',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(100,'exam.read','View exam information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(101,'exam.update','Update exam information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(102,'exam.delete','Delete exam entries',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(103,'exam.list','List all exam entries',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(104,'exam.schedule','Schedule exam dates',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(105,'exam.manage','Manage exam sessions',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(106,'entry_date.create','Create entry exam dates',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(107,'entry_date.read','View entry date information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(108,'entry_date.update','Update entry date information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(109,'entry_date.delete','Delete entry dates',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(110,'entry_date.list','List all entry dates',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(111,'entry_date.activate','Activate/deactivate entry dates',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(112,'exam_card.create','Create exam cards',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(113,'exam_card.read','View exam card information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(114,'exam_card.update','Update exam card information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(115,'exam_card.delete','Delete exam cards',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(116,'exam_card.list','List all exam cards',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(117,'exam_card.generate','Generate exam cards',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(118,'exam_card.print','Print exam cards',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(119,'exam_card.mark_printed','Mark exam cards as printed',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(120,'settings.read','View system settings',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(121,'settings.update','Update system settings',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(122,'settings.school','Manage school settings',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(123,'settings.email','Manage email settings',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(124,'settings.security','Manage security settings',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(125,'settings.backup','Manage system backups',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(126,'file_upload.create','Upload files',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(127,'file_upload.read','View uploaded files',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(128,'file_upload.update','Update file information',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(129,'file_upload.delete','Delete uploaded files',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(130,'file_upload.list','List all uploaded files',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(131,'file_upload.download','Download files',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(132,'report.create','Create reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(133,'report.read','View reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(134,'report.update','Update reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(135,'report.delete','Delete reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(136,'report.list','List all reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(137,'report.export','Export reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(138,'report.schedule','Schedule automated reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(139,'analytics.read','View analytics data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(140,'analytics.dashboard','Access dashboard analytics',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(141,'analytics.reports','Generate analytics reports',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(142,'analytics.export','Export analytics data',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(143,'system.logs','View system logs',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(144,'system.maintenance','Perform system maintenance',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(145,'system.backup','Create system backups',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(146,'system.restore','Restore system from backup',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(147,'system.monitor','Monitor system performance',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(148,'notification.create','Create notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(149,'notification.read','View notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(150,'notification.update','Update notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(151,'notification.delete','Delete notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(152,'notification.list','List all notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(153,'notification.send','Send notifications',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(154,'audit.read','View audit logs',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(155,'audit.list','List audit logs',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(156,'audit.export','Export audit logs',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(157,'audit.search','Search audit logs',1,'2025-10-05 06:00:26','2025-10-05 06:00:26'),(158,'student_profile.read','View own student profile',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(159,'student_profile.update','Update own student profile',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(160,'student_profile.upload_photo','Upload passport photo',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(161,'student_profile.change_password','Change own password',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(162,'student_application.create','Create new application',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(163,'student_application.read','View own applications',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(164,'student_application.update','Update draft applications',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(165,'student_application.delete','Delete draft applications',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(166,'student_application.submit','Submit applications',1,'2025-10-08 01:13:43','2025-10-08 01:13:43'),(167,'student_application.upload_docs','Upload application documents',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(168,'student_application.browse','Browse available programs',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(169,'student_payment.read','View own payment history',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(170,'student_payment.create','Initialize payments',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(171,'student_payment.verify','Verify payment status',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(172,'student_payment.receipt','Download payment receipts',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(173,'student_exam.read','View own exams',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(174,'student_exam.download_card','Download exam cards',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(175,'student_exam.view_schedule','View exam schedule',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(176,'student_result.read','View own results',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(177,'student_result.download','Download result certificates',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(178,'student_result.admission','Check admission status',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(179,'student_result.accept_offer','Accept admission offer',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(180,'student_result.decline_offer','Decline admission offer',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(181,'student_notification.read','View notifications',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(182,'student_notification.mark_read','Mark notifications as read',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(183,'student_notification.settings','Manage notification preferences',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(184,'student_support.contact','Contact support',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(185,'student_support.faq','View FAQ',1,'2025-10-08 01:13:44','2025-10-08 01:13:44'),(186,'student_analytics.read','View analytics and reports in student portal',1,'2025-10-26 17:12:05','2025-10-26 17:12:05'),(187,'student_report.read','View reports in student portal',1,'2025-10-26 17:12:05','2025-10-26 17:12:05'),(188,'admission_subject.read','View admission subjects',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(189,'admission_subject.create','Create admission subjects',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(190,'admission_subject.update','Update admission subjects',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(191,'admission_benchmark.read','View admission benchmark score',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(192,'admission_benchmark.update','Update admission benchmark score',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(193,'admission_score.create','Enter/update applicant admission scores',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(194,'admission_result.read','View admission results and successful candidates',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(195,'admission_decision.update','Update applicant admission decision',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(196,'admission_letter.generate','Generate admission letter PDF',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(197,'admission_letter.send','Send admission letters via email',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(198,'settings.template.read','View document templates',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(199,'settings.template.create','Create new document template version',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(200,'settings.template.update','Update existing document template',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(201,'settings.template.activate','Activate a document template version',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(202,'settings.template.preview','Preview rendered document template',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(203,'exam_assignment.manage','Assign and manage exam slots for applicants',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(204,'exam_calendar.read','View exam calendar slot availability',1,'2026-03-04 22:13:07','2026-03-04 22:13:07'),(205,'student.login.send','Send student login credentials via email',1,'2026-03-04 22:13:07','2026-03-04 22:13:07');

--
-- Table structure for table `role_permissions`
--

DROP TABLE IF EXISTS `role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_role_permission` (`role_id`,`permission_id`),
  KEY `idx_role_permissions_role` (`role_id`),
  KEY `idx_role_permissions_permission` (`permission_id`)
) ENGINE=InnoDB AUTO_INCREMENT=249 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` VALUES (59,8,37,'2025-10-06 17:20:39'),(60,8,38,'2025-10-06 17:20:39'),(61,8,39,'2025-10-06 17:20:39'),(62,8,40,'2025-10-06 17:20:39'),(63,8,41,'2025-10-06 17:20:39'),(64,8,42,'2025-10-06 17:20:39'),(65,8,31,'2025-10-06 17:20:39'),(66,8,32,'2025-10-06 17:20:39'),(67,8,33,'2025-10-06 17:20:39'),(68,8,34,'2025-10-06 17:20:39'),(69,8,35,'2025-10-06 17:20:39'),(70,8,36,'2025-10-06 17:20:39'),(71,8,24,'2025-10-06 17:20:39'),(72,8,25,'2025-10-06 17:20:39'),(73,8,26,'2025-10-06 17:20:39'),(74,8,27,'2025-10-06 17:20:39'),(75,8,28,'2025-10-06 17:20:39'),(76,8,29,'2025-10-06 17:20:39'),(77,8,30,'2025-10-06 17:20:39'),(78,9,168,'2025-10-08 01:14:50'),(79,9,162,'2025-10-08 01:14:50'),(80,9,165,'2025-10-08 01:14:50'),(81,9,163,'2025-10-08 01:14:50'),(82,9,166,'2025-10-08 01:14:50'),(83,9,164,'2025-10-08 01:14:50'),(84,9,167,'2025-10-08 01:14:50'),(85,9,174,'2025-10-08 01:14:50'),(86,9,173,'2025-10-08 01:14:50'),(87,9,175,'2025-10-08 01:14:50'),(88,9,182,'2025-10-08 01:14:50'),(89,9,181,'2025-10-08 01:14:50'),(90,9,183,'2025-10-08 01:14:50'),(91,9,170,'2025-10-08 01:14:50'),(92,9,169,'2025-10-08 01:14:50'),(93,9,172,'2025-10-08 01:14:50'),(94,9,171,'2025-10-08 01:14:50'),(95,9,161,'2025-10-08 01:14:50'),(96,9,158,'2025-10-08 01:14:50'),(97,9,159,'2025-10-08 01:14:50'),(98,9,160,'2025-10-08 01:14:50'),(99,9,179,'2025-10-08 01:14:50'),(100,9,178,'2025-10-08 01:14:50'),(101,9,180,'2025-10-08 01:14:50'),(102,9,177,'2025-10-08 01:14:50'),(103,9,176,'2025-10-08 01:14:50'),(104,9,184,'2025-10-08 01:14:50'),(105,9,185,'2025-10-08 01:14:50'),(106,9,126,'2025-10-08 01:14:50'),(107,9,127,'2025-10-08 01:14:50'),(108,9,131,'2025-10-08 01:14:50'),(109,9,149,'2025-10-08 01:14:50'),(110,10,68,'2025-10-22 18:29:46'),(111,10,69,'2025-10-22 18:29:46'),(112,10,70,'2025-10-22 18:29:46'),(113,10,71,'2025-10-22 18:29:46'),(114,10,72,'2025-10-22 18:29:46'),(115,10,73,'2025-10-22 18:29:46'),(116,10,74,'2025-10-22 18:29:46'),(117,10,75,'2025-10-22 18:29:46'),(118,10,77,'2025-10-22 18:29:46'),(119,10,78,'2025-10-22 18:29:46'),(120,10,76,'2025-10-22 18:29:46'),(121,10,79,'2025-10-22 18:29:46'),(122,10,80,'2025-10-22 18:29:46'),(123,10,81,'2025-10-22 18:29:46'),(124,10,82,'2025-10-22 18:29:46'),(125,10,83,'2025-10-22 18:29:46'),(126,10,84,'2025-10-22 18:29:46'),(127,10,85,'2025-10-22 18:29:46'),(128,10,86,'2025-10-22 18:29:46'),(129,10,87,'2025-10-22 18:29:46'),(130,10,88,'2025-10-22 18:29:46'),(131,10,89,'2025-10-22 18:29:46'),(132,10,90,'2025-10-22 18:29:46'),(133,10,91,'2025-10-22 18:29:46'),(134,10,92,'2025-10-22 18:29:46'),(135,10,93,'2025-10-22 18:29:46'),(136,10,94,'2025-10-22 18:29:46'),(137,10,95,'2025-10-22 18:29:46'),(138,10,96,'2025-10-22 18:29:46'),(139,10,97,'2025-10-22 18:29:46'),(140,10,98,'2025-10-22 18:29:46'),(141,10,99,'2025-10-22 18:29:46'),(142,10,100,'2025-10-22 18:29:46'),(143,10,101,'2025-10-22 18:29:46'),(144,10,102,'2025-10-22 18:29:46'),(145,10,103,'2025-10-22 18:29:46'),(146,10,105,'2025-10-22 18:29:46'),(147,10,104,'2025-10-22 18:29:46'),(148,10,112,'2025-10-22 18:29:46'),(149,10,113,'2025-10-22 18:29:46'),(150,10,114,'2025-10-22 18:29:46'),(151,10,115,'2025-10-22 18:29:46'),(152,10,116,'2025-10-22 18:29:46'),(153,10,117,'2025-10-22 18:29:46'),(154,10,118,'2025-10-22 18:29:46'),(155,10,119,'2025-10-22 18:29:46'),(156,10,106,'2025-10-22 18:29:46'),(157,10,107,'2025-10-22 18:29:46'),(158,10,108,'2025-10-22 18:29:46'),(159,10,109,'2025-10-22 18:29:46'),(160,10,110,'2025-10-22 18:29:46'),(161,10,111,'2025-10-22 18:29:46'),(162,10,43,'2025-10-22 18:29:46'),(163,10,44,'2025-10-22 18:29:46'),(164,10,45,'2025-10-22 18:29:46'),(165,10,46,'2025-10-22 18:29:46'),(166,10,47,'2025-10-22 18:29:46'),(167,10,49,'2025-10-22 18:29:46'),(168,10,50,'2025-10-22 18:29:46'),(169,10,48,'2025-10-22 18:29:46'),(170,10,51,'2025-10-22 18:29:46'),(171,10,52,'2025-10-22 18:29:46'),(172,10,53,'2025-10-22 18:29:46'),(173,10,54,'2025-10-22 18:29:46'),(174,10,55,'2025-10-22 18:29:46'),(175,10,56,'2025-10-22 18:29:46'),(176,10,57,'2025-10-22 18:29:46'),(177,10,58,'2025-10-22 18:29:46'),(178,10,59,'2025-10-22 18:29:46'),(179,10,60,'2025-10-22 18:29:46'),(180,10,61,'2025-10-22 18:29:46'),(181,10,62,'2025-10-22 18:29:46'),(182,10,63,'2025-10-22 18:29:46'),(183,10,64,'2025-10-22 18:29:46'),(184,10,65,'2025-10-22 18:29:46'),(185,10,66,'2025-10-22 18:29:46'),(186,10,67,'2025-10-22 18:29:46'),(187,10,24,'2025-10-22 18:29:46'),(188,10,25,'2025-10-22 18:29:46'),(189,10,26,'2025-10-22 18:29:46'),(190,10,28,'2025-10-22 18:29:46'),(191,10,126,'2025-10-22 18:29:46'),(192,10,127,'2025-10-22 18:29:46'),(193,10,128,'2025-10-22 18:29:46'),(194,10,129,'2025-10-22 18:29:46'),(195,10,130,'2025-10-22 18:29:46'),(196,10,131,'2025-10-22 18:29:46'),(197,10,148,'2025-10-22 18:29:46'),(198,10,149,'2025-10-22 18:29:46'),(199,10,150,'2025-10-22 18:29:46'),(200,10,151,'2025-10-22 18:29:46'),(201,10,152,'2025-10-22 18:29:46'),(202,10,153,'2025-10-22 18:29:46'),(203,10,132,'2025-10-22 18:29:46'),(204,10,133,'2025-10-22 18:29:46'),(205,10,134,'2025-10-22 18:29:46'),(206,10,135,'2025-10-22 18:29:46'),(207,10,136,'2025-10-22 18:29:46'),(208,10,137,'2025-10-22 18:29:46'),(209,10,138,'2025-10-22 18:29:46'),(210,10,139,'2025-10-22 18:29:46'),(211,10,140,'2025-10-22 18:29:46'),(212,10,120,'2025-10-22 18:29:46'),(213,10,122,'2025-10-22 18:29:46'),(214,10,123,'2025-10-22 18:29:46'),(215,10,124,'2025-10-22 18:29:46'),(216,9,186,'2025-10-26 17:14:11'),(217,9,187,'2025-10-26 17:14:11'),(218,8,191,'2026-03-04 22:13:07'),(219,8,192,'2026-03-04 22:13:07'),(220,8,195,'2026-03-04 22:13:07'),(221,8,196,'2026-03-04 22:13:07'),(222,8,197,'2026-03-04 22:13:07'),(223,8,194,'2026-03-04 22:13:07'),(224,8,193,'2026-03-04 22:13:07'),(225,8,189,'2026-03-04 22:13:07'),(226,8,188,'2026-03-04 22:13:07'),(227,8,190,'2026-03-04 22:13:07'),(228,8,203,'2026-03-04 22:13:07'),(229,8,204,'2026-03-04 22:13:07'),(230,8,201,'2026-03-04 22:13:07'),(231,8,199,'2026-03-04 22:13:07'),(232,8,202,'2026-03-04 22:13:07'),(233,8,198,'2026-03-04 22:13:07'),(234,8,200,'2026-03-04 22:13:07'),(235,8,205,'2026-03-04 22:13:07');

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `idx_roles_name` (`name`),
  KEY `idx_roles_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` VALUES (8,'Super Admin','The highest user role',1,'2025-09-30 14:41:05','2025-09-30 14:41:05'),(9,'Student','Student role for applicants',1,'2025-10-06 18:14:34','2025-10-06 18:14:34'),(10,'Administrator','Full complete none assisted role',1,'2025-10-06 18:22:09','2025-10-06 18:22:09');

--
-- Table structure for table `school_settings`
--

DROP TABLE IF EXISTS `school_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `school_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `school_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `school_logo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_favicon` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `school_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school_motto` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `school_mission` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `school_vision` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `academic_year` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application_fee` decimal(10,2) DEFAULT '0.00',
  `currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'NGN',
  `timezone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Africa/Lagos',
  `date_format` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'YYYY-MM-DD',
  `time_format` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '24h',
  `language` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'en',
  `theme_color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `school_settings`
--

INSERT INTO `school_settings` VALUES (1,'Deepflux Academy','uploads/school/logo-1760844594610-642762109.png','uploads/school/favicon-1761095934646.png','2nd Avenue','+23480222222','info@deepflux.com.ng','https://deepflux.com.ng','A good learning','','','2025',0.00,'NGN','Africa/Lagos','YYYY-MM-DD','24h','en','#007bff',NULL,'2025-10-19 02:31:45','2026-03-04 10:46:15',14,14),(2,'Your School Name','',NULL,'','','','','','','','2025',0.00,'NGN','Africa/Lagos','YYYY-MM-DD','24h','en','#007bff',NULL,'2025-10-19 02:31:45','2025-10-19 02:31:45',14,14);

--
-- Table structure for table `security_settings`
--

DROP TABLE IF EXISTS `security_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `security_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password_policy_enabled` tinyint(1) DEFAULT '1',
  `password_min_length` int DEFAULT '8',
  `password_require_uppercase` tinyint(1) DEFAULT '1',
  `password_require_lowercase` tinyint(1) DEFAULT '1',
  `password_require_numbers` tinyint(1) DEFAULT '1',
  `password_require_symbols` tinyint(1) DEFAULT '0',
  `password_expiry_days` int DEFAULT '90',
  `max_login_attempts` int DEFAULT '5',
  `lockout_duration_minutes` int DEFAULT '30',
  `session_timeout_minutes` int DEFAULT '60',
  `two_factor_enabled` tinyint(1) DEFAULT '0',
  `two_factor_method` enum('email','sms','app') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'email',
  `ip_whitelist_enabled` tinyint(1) DEFAULT '0',
  `ip_whitelist` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ip_blacklist_enabled` tinyint(1) DEFAULT '0',
  `ip_blacklist` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `audit_log_enabled` tinyint(1) DEFAULT '1',
  `audit_log_retention_days` int DEFAULT '365',
  `ssl_enforced` tinyint(1) DEFAULT '1',
  `csrf_protection_enabled` tinyint(1) DEFAULT '1',
  `xss_protection_enabled` tinyint(1) DEFAULT '1',
  `custom_settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `security_settings`
--

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `session_id` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `expires` int unsigned NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

--
-- Table structure for table `student_schema_fields`
--

DROP TABLE IF EXISTS `student_schema_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_schema_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_id` int NOT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_label` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` enum('text','number','email','tel','date','select','textarea','file','checkbox','radio') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_options` json DEFAULT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `field_order` int DEFAULT '0',
  `validation_rules` json DEFAULT NULL,
  `help_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_schema_field` (`schema_id`,`field_name`),
  KEY `idx_student_fields_schema` (`schema_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_schema_fields`
--

--
-- Table structure for table `student_schemas`
--

DROP TABLE IF EXISTS `student_schemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_schemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `schema_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `schema_name` (`schema_name`),
  KEY `created_by` (`created_by`),
  KEY `idx_student_schemas_active` (`is_active`),
  KEY `idx_student_schemas_name` (`schema_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_schemas`
--

INSERT INTO `student_schemas` VALUES (1,'undergraduate','Undergraduate Student','Schema for undergraduate degree programs',1,'2025-10-08 00:17:49','2025-10-08 00:17:49',14),(2,'postgraduate','Postgraduate Student','Schema for masters and PhD programs',1,'2025-10-08 00:17:49','2025-10-08 00:17:49',14),(3,'certificate','Certificate Program','Schema for certificate programs',1,'2025-10-08 00:17:49','2025-10-08 00:17:49',14),(4,'primary','Primary School Student','Schema for primary school students (Classes 1-6)',1,'2025-10-08 01:23:43','2025-10-08 01:23:43',14),(5,'jss','Junior Secondary Student (JSS)','Schema for junior secondary students (JSS 1-3)',1,'2025-10-08 01:23:59','2025-10-08 01:23:59',14),(6,'sss','Senior Secondary Student (SSS)','Schema for senior secondary students (SSS 1-3)',1,'2025-10-08 01:23:59','2025-10-08 01:23:59',14),(7,'nursery','Nursery/Pre-School','Schema for nursery and pre-school children',1,'2025-10-08 01:23:59','2025-10-08 01:23:59',14);

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` int NOT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` enum('male','female','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Nigeria',
  `postal_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_relationship` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `previous_school` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `graduation_year` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `profile_photo` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('active','inactive','graduated','suspended','withdrawn') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'active',
  `custom_data` json DEFAULT NULL,
  `welcome_email_sent` tinyint(1) DEFAULT '0',
  `welcome_email_sent_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `student_id` (`student_id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `created_by` (`created_by`),
  KEY `idx_students_student_id` (`student_id`),
  KEY `idx_students_email` (`email`),
  KEY `idx_students_user_id` (`user_id`),
  KEY `idx_students_schema` (`schema_id`),
  KEY `idx_students_status` (`status`),
  KEY `idx_students_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

INSERT INTO `students` VALUES (4,'STUD20250004',5,'Michael','Brown','','michael.brown@parent.com','+2348066665555','2010-09-25','male','','','','Nigeria',NULL,'Mrs. Jane Brown','+2348077776666','','mother',NULL,NULL,21,'/uploads/profiles/STUDENT_4_1760778471719.jpg','active',NULL,0,NULL,'2025-10-08 02:33:00','2025-10-19 01:45:45',14),(5,'STUD20250005',5,'anthony','Oranu','','anthony1@gmail.com','+2348038389474','1982-06-30','male','2nd Avenue','Festac','Lagos','Nigeria','23401','Oranu Williams','+2348035089474','chukwumaoranu@gmail.com','Parent','Nazareth School',2023,24,'/uploads/profiles/STUDENT_5_1761615484020.jpg','active',NULL,1,'2025-10-25 10:02:00','2025-10-25 11:01:59','2025-10-28 01:54:36',14),(6,'STUD20260001',5,'Philips','Aniete ','','deepfluxlimited@gmail.com','+2348038389248','1985-04-18','male','Salvation Avenue\nOff Purewater , Omonile','Abule Ado','Lagos','Nigeria','23401','Mr & Mrs Aniete Joseph','+2348035089474','oranu@outlook.com','Parent','Nazareth School, Festac Town',2023,25,NULL,'active',NULL,0,NULL,'2026-03-05 09:52:29','2026-03-05 09:52:59',14);

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maintenance_mode` tinyint(1) DEFAULT '0',
  `debug_mode` tinyint(1) DEFAULT '0',
  `log_level` enum('error','warn','info','debug') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'info',
  `session_timeout` int DEFAULT '3600',
  `max_login_attempts` int DEFAULT '5',
  `password_min_length` int DEFAULT '8',
  `require_email_verification` tinyint(1) DEFAULT '1',
  `auto_backup` tinyint(1) DEFAULT '1',
  `backup_frequency` enum('hourly','daily','weekly','monthly') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'daily',
  `backup_retention_days` int DEFAULT '30',
  `cache_enabled` tinyint(1) DEFAULT '1',
  `cache_ttl` int DEFAULT '300',
  `rate_limiting` tinyint(1) DEFAULT '1',
  `rate_limit_requests` int DEFAULT '100',
  `rate_limit_window` int DEFAULT '900',
  `custom_settings` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by` int DEFAULT NULL,
  `updated_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `updated_by` (`updated_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `temp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `email_verified` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_username` (`username`),
  KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES (14,'oranich','oranich@gmail.com','$2b$12$RYD5RBuIEnJDIpbNT.WUie2UCJo.6wAF4x0Q1ls4bqtZCcBu0.zVe',NULL,8,1,0,'2025-09-30 13:04:06','2025-10-06 17:55:17'),(15,'john.doe','john.doe@test.com','$2b$10$6.SzEMe9Regh4Es8Xudu5e9hAGDBUqnyYofC/JBcqntQsc3iRTDeK',NULL,NULL,1,0,'2025-10-07 16:54:31','2025-10-07 16:54:31'),(16,'jane.smith','jane.smith@company.com','$2b$10$QKwAhEloHCOxSyDfPckTv.dHbx7nFv2nG.1SMclcJP7.EgpEuaM/W',NULL,NULL,1,0,'2025-10-07 17:00:38','2025-10-07 17:00:38'),(17,'bob.johnson','bob.johnson@company.com','$2b$10$lgBOewelxDx3e5BSOLtajOtlayTKu3qKajDbUc1/fbk.8QezFJJnK',NULL,NULL,1,0,'2025-10-07 17:01:25','2025-10-07 17:01:25'),(18,'alice.williams','alice.williams@student.com','$2b$10$e.dpz.CfYNrlkBaIEnro1.A9UUpABBOfaj9.l24h0TnNQmNgjsYei',NULL,9,1,0,'2025-10-08 00:32:44','2025-10-08 00:32:44'),(19,'test.student','test.student@parent.com','$2b$10$Y16hLZy1Dr1dbGYyaHXBO.Evw1ZtwqNZsGeHzYb5CsOUzJSnTHKmS',NULL,9,1,0,'2025-10-08 02:10:25','2025-10-08 02:10:25'),(20,'sarah.johnson','sarah.johnson@parent.com','$2b$10$oisOshxfvsxz6gsYGTEfAuX/xpzJLSo6dhptPH3R3rPKFnNZCJpEO',NULL,9,1,0,'2025-10-08 02:25:34','2025-10-08 02:25:34'),(21,'michael.brown','michael.brown@parent.com','$2b$10$PM3zYIVqvms35zeykupprOPc.IFTMvhAbxb/7NumRF5NbvtqaAweW','O@Sh5KPd?ETZ',9,1,0,'2025-10-08 02:33:00','2025-10-08 02:33:00'),(23,'amaka.oranu','oranu2@outlook.com','$2b$10$16WtFyoF6ixXzYdQtkjIOODLiFPr5LIkMFLbWqgKZCJDn2Af.LrT.','PpXlz5Y?Wf&i',10,1,0,'2025-10-23 18:27:16','2025-10-26 06:35:43'),(24,'anthony.oranu','anthony1@gmail.com','$2b$10$EuiYmCHbSIj4URGRhNfDyeJQB7Q.ukapOIIrU1b06yTqZy3gulAt2','$68NexVFJ5Gw',9,1,0,'2025-10-25 11:01:59','2025-11-02 10:23:44'),(25,'philips.aniete','deepfluxlimited@gmail.com','$2b$10$BrQZbiGY7LsTW3uWiBeb3OnvoJ/5YcqWTkGgVWczETwyA6CT1QGzS','Tl%x?91gRz10',9,1,0,'2026-03-05 09:52:59','2026-03-05 09:52:59');

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-21 17:21:31
